<?php
define('TITLE', 'Payment');
define('PAGE', 'memberpayment');
include('includes/header.php');
include('../dbConnection.php');
session_start();

if ($_SESSION['is_login']) {
    $mEmail = $_SESSION['mEmail'];
} else {
    echo "<script> location.href='payment.php'; </script>";
    exit;
}

function renderPlanCard($title, $price, $features, $planName, $currency = "INR")
{
    echo '
    <div class="col-sm-6">
        <div class="card mb-5 rounded-3 shadow-sm border-primary">
            <div class="card-header py-3 text-white bg-primary border-primary">
                <h4 class="my-0 fw-normal">' . htmlspecialchars($title) . '</h4>
            </div>
            <div class="card-body">
                <h1 class="card-title pricing-card-title">₹' . htmlspecialchars($price) . '<small class="text-muted fw-light">/' . htmlspecialchars($currency) . '</small></h1>
                <ul class="list-unstyled mt-3 mb-4">';
    foreach ($features as $feature) {
        echo '<li>' . htmlspecialchars($feature) . '</li>';
    }
    echo '</ul>
                <a href="payment_processor.php?plan=' . urlencode($planName) . '&price=' . urlencode($price) . '" class="btn btn-primary">Subscribe Now</a>
            </div>
        </div>
    </div>';
}

?>

<style>
    .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        user-select: none;
    }

    @media (min-width: 768px) {
        .bd-placeholder-img-lg {
            font-size: 3.5rem;
        }
    }
</style>

<link href="../css/pricing.css" rel="stylesheet">
</head>
<body>
<div class="container py-1">
    <div class="pricing-header p-3 pb-md-4 mx-auto text-center">
        <h1 class="display-4 fw-normal"><u>Membership Plan</u></h1>
        <p class="fs-5 text-muted">Get started today by getting your gym membership subscription plan</p>
    </div>

    <main class="container-fluid">
        <div class="row row-cols-1 row-cols-md-3 mb-3 text-center">
            <?php
            renderPlanCard(
                "1 Month",
                "1200",
                ["1 week free lessons", "Fast transactions", "Email support", "Help center access"],
                "1 Month"
            );

            renderPlanCard(
                "6 Months",
                "7000",
                ["1 Month free lessons", "Priority email support", "Help center access"],
                "6 Months"
            );

            renderPlanCard(
                "1 Year",
                "10000",
                ["3 months free lessons", "Free beverages", "Phone and email support", "Help center access"],
                "1 Year"
            );
            ?>
        </div>
    </main>
</div>

<?php
include('includes/footer.php');
?>
