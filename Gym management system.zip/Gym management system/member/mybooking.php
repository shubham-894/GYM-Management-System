<?php
define('TITLE', 'My Booking');
define('PAGE', 'MyBooking');
include('includes/header.php'); 
include('../dbConnection.php');

session_start();
if (!isset($_SESSION['is_login']) || !isset($_SESSION['mEmail'])) {
    echo "<script> location.href='memberLogin.php'; </script>";
    exit;
}

$mEmail = $_SESSION['mEmail'];

// Debugging: Ensure email is retrieved correctly
// var_dump($mEmail);

?>

<div class="col-sm-9 col-md-10 mt-5 text-center">
    <p class="bg-dark text-white p-2">My Booking</p>

    <?php
    $sql = "SELECT * FROM submitbookingt_tb WHERE member_email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $mEmail);
    $stmt->execute();
    $result = $stmt->get_result();

    // Debugging: Check number of rows
    // var_dump($result->num_rows);

    if ($result->num_rows > 0) {
        echo '<table class="table table-bordered table-hover">
            <thead>
                <tr class="active bg-secondary">
                    <th scope="col">Booking ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Booking Type</th>
                    <th scope="col">Address</th>
                    <th scope="col">Mobile</th>
                    <th scope="col">Date</th>
                    <th scope="col">Cancel</th>
                </tr>
            </thead>
            <tbody>';

        while ($row = $result->fetch_assoc()) {
            echo '<tr>
                <th scope="row">' . htmlspecialchars($row["Booking_id"]) . '</th>
                <td>' . htmlspecialchars($row["member_name"]) . '</td>
                <td>' . htmlspecialchars($row["member_email"]) . '</td>
                <td>' . htmlspecialchars($row["booking_type"]) . '</td>
                <td>' . htmlspecialchars($row["member_add1"]) . '</td>
                <td>' . htmlspecialchars($row["member_mobile"]) . '</td>
                <td>' . htmlspecialchars($row["member_date"]) . '</td>
                <td>  
                    <form action="" method="POST" class="d-inline">
                        <input type="hidden" name="id" value="' . htmlspecialchars($row["Booking_id"]) . '">
                        <button type="submit" class="btn btn-danger" name="delete" value="Delete">
                            <i class="far fa-trash-alt"></i>
                        </button>
                    </form>
                </td>
            </tr>';
        }

        echo '</tbody>
        </table>';
    } else {
        echo "<p class='alert alert-info'>No Bookings Found</p>";
    }

    // Handle delete request
    if (isset($_POST['delete'])) {
        $id = (int) $_POST['id'];
        $deleteSql = "DELETE FROM submitbookingt_tb WHERE Booking_id = ?";
        $deleteStmt = $conn->prepare($deleteSql);
        $deleteStmt->bind_param("i", $id);

        if ($deleteStmt->execute()) {
            echo '<script>window.location.reload();</script>';
        } else {
            echo "<p class='alert alert-danger'>Unable to Delete Data</p>";
        }
    }
    ?>

</div>

<?php include('includes/footer.php'); ?>
