<?php
session_start();

//  the user is logged in
if (!isset($_SESSION['is_login'])) {
    echo "<script> location.href='payment.php'; </script>";
    exit;
}

// Get payment details
$plan = isset($_GET['plan']) ? htmlspecialchars($_GET['plan']) : "Unknown Plan";
$price = isset($_GET['price']) ? htmlspecialchars($_GET['price']) : "0.00";
$date = date("Y-m-d H:i:s");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Receipt</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            background: #f4f4f9;
            font-family: Arial, sans-serif;
        }

        .container {
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            max-width: 400px;
            text-align: center;
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
        }

        p {
            margin: 10px 0;
            color: #555;
        }

        strong {
            color: #000;
        }

        .btn-container {
            margin-top: 20px;
        }

        .btn {
            display: inline-block;
            margin: 5px;
            padding: 10px 20px;
            background: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s ease;
        }

        .btn:hover {
            background: #0056b3;
        }

        .btn.print {
            background: #28a745;
        }

        .btn.print:hover {
            background: #218838;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Payment Receipt</h1>
        <p>Thank you for your payment!</p>
        <p><strong>Plan:</strong> <?php echo $plan; ?></p>
        <p><strong>Amount Paid:</strong> ₹<?php echo $price; ?></p>
        <p><strong>Date:</strong> <?php echo $date; ?></p>
        <div class="btn-container">
            <button onclick="window.print()" class="btn print">Print Receipt</button>
        </div>
    </div>
</body>
<?php
include('includes/footer.php');
?>
</html>
